#include "hello.h"

void main() {
     Hello();
}
