#!/usr/bin/python

from pyhello import ffi, lib
lib.Hello()
