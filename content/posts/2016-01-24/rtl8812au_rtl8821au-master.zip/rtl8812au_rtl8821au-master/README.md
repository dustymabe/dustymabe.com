# rtl8812au_rtl8821au
Driver for rtl8812au and rtl8821au (rtl8811au) based on Realtek's 4.3.14 version

##Arch Linux port
https://aur.archlinux.org/packages/rtl8812au_rtl8821au-dkms-git
